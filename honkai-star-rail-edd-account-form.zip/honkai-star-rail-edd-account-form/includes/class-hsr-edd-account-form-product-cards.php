<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class HSR_EDD_Account_Form_Product_Cards {
	const SHORTCODE = 'hsr_account_cards';
	const MY_ACCOUNTS_SHORTCODE = 'hsr_my_account_cards';
	const PROFILE_ACCOUNTS_SHORTCODE = 'honkai_profile_star_rail_accounts';

	/**
	 * @var HSR_EDD_Account_Form_Admin
	 */
	private $admin;

	/**
	 * @var string
	 */
	private $download_category_taxonomy;

	/**
	 * @var string
	 */
	private $download_category_slug;

	/**
	 * @param HSR_EDD_Account_Form_Admin $admin Admin dependency.
	 */
	public function __construct( HSR_EDD_Account_Form_Admin $admin ) {
		$this->admin                      = $admin;
		$this->download_category_taxonomy = HSR_EDD_Account_Form_Frontend::DOWNLOAD_CATEGORY_TAXONOMY;
		$this->download_category_slug     = HSR_EDD_Account_Form_Frontend::DOWNLOAD_CATEGORY_SLUG;
	}

	public function register_shortcode() {
		add_shortcode( self::SHORTCODE, array( $this, 'render_shortcode' ) );
		add_shortcode( self::MY_ACCOUNTS_SHORTCODE, array( $this, 'render_my_accounts_shortcode' ) );
		add_shortcode( self::PROFILE_ACCOUNTS_SHORTCODE, array( $this, 'render_profile_accounts_shortcode' ) );
	}

	public function register_assets() {
		wp_register_style( 'hsr-account-cards-style', HSR_EDD_FORM_URL . 'assets/css/product-cards.css', array(), HSR_EDD_FORM_VERSION );
		wp_register_script( 'hsr-account-cards-script', HSR_EDD_FORM_URL . 'assets/js/product-cards.js', array(), HSR_EDD_FORM_VERSION, true );
	}

	/**
	 * @param array<string,mixed> $atts Shortcode attributes.
	 * @return string
	 */
	public function render_shortcode( $atts ) {
		return $this->render_cards( $atts, false );
	}

	/**
	 * @param array<string,mixed> $atts Shortcode attributes.
	 * @return string
	 */
	public function render_my_accounts_shortcode( $atts ) {
		if ( ! is_user_logged_in() ) {
			return '<p class="hsr-product-cards__message">' . esc_html__( 'برای مشاهده آکانت‌های خود ابتدا وارد شوید.', 'honkai-star-rail-edd-account-form' ) . '</p>';
		}

		return $this->render_cards( $atts, true );
	}

	/**
	 * @param array<string,mixed> $atts Shortcode attributes.
	 * @return string
	 */
	public function render_profile_accounts_shortcode( $atts ) {
		$atts = shortcode_atts(
			array(
				'author_id'      => 0,
				'posts_per_page' => 12,
			),
			$atts,
			self::PROFILE_ACCOUNTS_SHORTCODE
		);

		$author_id = absint( $atts['author_id'] );
		if ( $author_id <= 0 || ! get_user_by( 'id', $author_id ) ) {
			return '<p class="hsr-product-cards__message">' . esc_html__( 'کاربر معتبری برای نمایش آکانت‌ها مشخص نشده است.', 'honkai-star-rail-edd-account-form' ) . '</p>';
		}

		$atts['author_id'] = $author_id;

		return $this->render_cards( $atts, false, true );
	}

	/**
	 * @param array<string,mixed> $atts Shortcode attributes.
	 * @param bool               $only_current_user Whether to restrict cards to current user.
	 * @param bool               $only_author       Whether to restrict cards to provided author ID.
	 * @return string
	 */
	private function render_cards( $atts, $only_current_user, $only_author = false ) {
		wp_enqueue_style( 'hsr-account-cards-style' );
		wp_enqueue_script( 'hsr-account-cards-script' );

		$hsr_card_seo_css = <<<'CSS'
.hsr-product-card__headline{display:flex;align-items:center;gap:8px;flex-wrap:wrap;}
.hsr-product-card__subtitle{margin:-2px 0 0;font-size:12px;line-height:1.4;color:var(--hsr-text-dim,#9fb2dd);}
CSS;

		wp_add_inline_style( 'hsr-account-cards-style', $hsr_card_seo_css );

		if ( ! post_type_exists( 'download' ) ) {
			return '<p class="hsr-product-cards__message">' . esc_html__( 'Easy Digital Downloads فعال نیست.', 'honkai-star-rail-edd-account-form' ) . '</p>';
		}

		$atts_defaults = array(
			'posts_per_page' => 12,
		);

		if ( $only_author ) {
			$atts_defaults['author_id'] = 0;
		}

		$atts = shortcode_atts(
			$atts_defaults,
			$atts,
			$only_author ? self::PROFILE_ACCOUNTS_SHORTCODE : ( $only_current_user ? self::MY_ACCOUNTS_SHORTCODE : self::SHORTCODE )
		);

		$query_args = array(
			'post_type'      => 'download',
			'post_status'    => $only_current_user ? array( 'publish', 'pending', 'draft' ) : 'publish',
			'posts_per_page' => max( 1, absint( $atts['posts_per_page'] ) ),
			'no_found_rows'  => true,
		);

		if ( $only_current_user ) {
			$query_args['author'] = get_current_user_id();
		} elseif ( $only_author ) {
			$author_id = isset( $atts['author_id'] ) ? absint( $atts['author_id'] ) : 0;
			if ( $author_id <= 0 ) {
				return '<p class="hsr-product-cards__message">' . esc_html__( 'کاربر معتبری برای نمایش آکانت‌ها مشخص نشده است.', 'honkai-star-rail-edd-account-form' ) . '</p>';
			}

			$query_args['author'] = $author_id;
		}

		if ( taxonomy_exists( $this->download_category_taxonomy ) ) {
			$query_args['tax_query'] = array(
				array(
					'taxonomy' => $this->download_category_taxonomy,
					'field'    => 'slug',
					'terms'    => $this->download_category_slug,
				),
			);
		}

		$query = new WP_Query( $query_args );

		if ( ! $query->have_posts() ) {
			$message = $only_current_user
				? esc_html__( 'هنوز آکانتی برای شما ثبت نشده است.', 'honkai-star-rail-edd-account-form' )
				: ( $only_author
					? esc_html__( 'این کاربر هنوز آکانت Honkai Star Rail برای نمایش ثبت نکرده است.', 'honkai-star-rail-edd-account-form' )
					: esc_html__( 'فعلاً محصولی برای نمایش وجود ندارد.', 'honkai-star-rail-edd-account-form' ) );
			return '<p class="hsr-product-cards__message">' . $message . '</p>';
		}

		$cards = $this->prepare_cards_data( $query, $only_current_user );
		$show_filters = ! $only_current_user && ! $only_author;
		wp_reset_postdata();

		$template_file = HSR_EDD_FORM_DIR . 'templates/shortcode-hsr-account-cards.php';
		if ( ! file_exists( $template_file ) ) {
			return '';
		}

		ob_start();
		require $template_file;
		return ob_get_clean();
	}

	/**
	 * @param WP_Query $query Downloads query.
	 * @return array<int,array<string,mixed>>
	 */
	public function prepare_cards_data( WP_Query $query, $include_status ) {
		$meta_rows = array(
			'trailblaze_level'       => 'تربلیز لول',
			'server'                => 'سرور',
			'character_event_warp_pity' => 'پیتی وارپ کاراکتر',
			'light_cone_event_warp_pity'    => 'پیتی وارپ لایت‌کون',
			'standard_warp_pity'  => 'پیتی وارپ استاندارد',
			'star_rail_passes'        => 'تعداد پاس مانده',
			'stellar_jade'               => 'استلار جید',
			'oneiric_shard'             => 'وانیریک شارد',
			'special_passes'        => 'تعداد اسپشیال پس',
			'eidolons_summary'   => 'خلاصه Eidolon کاراکترها',
		);

		$character_map = $this->build_item_image_map( $this->admin->get_character_images(), HSR_EDD_CHARACTERS_IMG_BASE_URL, HSR_EDD_CHARACTERS_IMAGE_EXT );
		$weapon_map    = $this->build_item_image_map( $this->admin->get_light_cone_images(), HSR_EDD_LIGHTCONES_IMG_BASE_URL, HSR_EDD_LIGHTCONES_IMAGE_EXT );
		$cards         = array();

		while ( $query->have_posts() ) {
			$query->the_post();
			$post_id = get_the_ID();
			$stats   = array();
			$trailblaze_level_raw = absint( get_post_meta( $post_id, 'hsr_trailblaze_level', true ) );
			$server_raw          = sanitize_text_field( (string) get_post_meta( $post_id, 'hsr_server', true ) );
			$created_at          = get_post_time( 'U', true, $post_id );
			$seo_titles          = $this->build_seo_titles( $server_raw, $trailblaze_level_raw );

			foreach ( $meta_rows as $meta_key => $label ) {
				$value   = (string) get_post_meta( $post_id, 'hsr_' . $meta_key, true );
				$stats[] = array(
					'label' => $label,
					'value' => '' !== $value ? $value : '-',
				);
			}

			$description = (string) get_post_meta( $post_id, 'hsr_description', true );
			$price       = (string) get_post_meta( $post_id, 'edd_price', true );
			$price_raw   = is_numeric( $price ) ? (float) $price : 0;

			$characters = $this->extract_meta_list( (string) get_post_meta( $post_id, 'hsr_selected_characters', true ) );
			$light_cones    = $this->extract_meta_list( (string) get_post_meta( $post_id, 'hsr_selected_light_cones', true ) );
			$gallery    = $this->extract_gallery_urls(
				$post_id,
				(string) get_post_meta( $post_id, HSR_EDD_Account_Form_Frontend::UPLOADED_IMAGE_META_KEY, true )
			);

			$status_data = $this->get_status_data( get_post_status( $post_id ) );

			$cards[] = array(
				'id'                      => (int) $post_id,
				'title'                   => $seo_titles['primary'],
				'secondary_title'         => $seo_titles['fa'],
				'stats'                   => $stats,
				'price'                   => '' !== $price ? number_format_i18n( (float) $price ) : '-',
				'price_raw'               => $price_raw,
				'trailblaze_level_raw'     => $trailblaze_level_raw,
				'server_raw'              => $server_raw,
				'created_at'              => (int) $created_at,
				'status_label'            => $include_status ? $status_data['label'] : '',
				'status_class'            => $include_status ? $status_data['class'] : '',
				'characters_filter_items' => $characters,
				'light_cones_filter_items'    => $light_cones,
				'description_hover'       => $this->prepare_hover_text( $description ),
				'characters_hover_items'  => $this->prepare_hover_items( $characters, $character_map ),
				'light_cones_hover_items'     => $this->prepare_hover_items( $light_cones, $weapon_map ),
				'gallery_images'          => $gallery,
			);
		}

		return $cards;
	}

	/**
	 * @param string $server Server value.
	 * @param int    $trailblaze_level Trailblaze level.
	 * @return array<string,string>
	 */
	private function build_seo_titles( $server, $trailblaze_level ) {
		$server_label = strtoupper( sanitize_text_field( (string) $server ) );
		$level        = max( 1, absint( $trailblaze_level ) );

		return array(
			'primary' => sprintf( 'honkai: star rail account - %1$s - Lv %2$d', $server_label, $level ),
			'fa'      => sprintf( 'آکانت هونکای استار ریل - %1$s - Lv %2$d', $server_label, $level ),
		);
	}

	/**
	 * @param string $meta Comma separated values.
	 * @return array<int,string>
	 */
	private function extract_meta_list( $meta ) {
		if ( '' === $meta ) {
			return array();
		}

		$items = array_map( 'trim', explode( ',', $meta ) );
		$items = array_filter(
			$items,
			static function ( $item ) {
				return '' !== $item;
			}
		);

		return array_values( array_unique( $items ) );
	}

	/**
	 * @param int    $post_id     Product post ID.
	 * @param string $gallery_ids Comma separated attachment IDs.
	 * @return array<int,array{url:string,alt:string}>
	 */
	private function extract_gallery_urls( $post_id, $gallery_ids ) {
		$ids           = $this->extract_meta_list( $gallery_ids );
		$attachment_ids = array();

		foreach ( $ids as $id_raw ) {
			$attachment_id = absint( $id_raw );
			if ( $attachment_id > 0 ) {
				$attachment_ids[] = $attachment_id;
			}
		}

		$thumbnail_id = get_post_thumbnail_id( $post_id );
		if ( $thumbnail_id > 0 ) {
			array_unshift( $attachment_ids, $thumbnail_id );
		}

				$attached_images = get_children(
			array(
				'post_parent'    => $post_id,
				'post_type'      => 'attachment',
				'post_mime_type' => 'image',
				'orderby'        => 'menu_order ID',
				'order'          => 'ASC',
				'fields'         => 'ids',
			)
		);

		if ( ! empty( $attached_images ) && is_array( $attached_images ) ) {
			$attachment_ids = array_merge( $attachment_ids, array_map( 'absint', $attached_images ) );
		}

		$attachment_ids = array_values( array_unique( array_filter( $attachment_ids ) ) );
		if ( empty( $attachment_ids ) ) {
			return array();
		}

		$images = array();
		foreach ( $attachment_ids as $attachment_id ) {

			$image_url = wp_get_attachment_image_url( $attachment_id, 'large' );
			if ( ! $image_url ) {
				continue;
			}

			$alt = get_post_meta( $attachment_id, '_wp_attachment_image_alt', true );
			if ( '' === $alt ) {
				$alt = get_the_title( $attachment_id );
			}

			$images[] = array(
				'url' => esc_url( $image_url ),
				'alt' => sanitize_text_field( (string) $alt ),
			);
		}

		return $images;
	}

	/**
	 * @param array<int,array{name:string,file:string}> $items Raw items.
	 * @return array<string,string>
	 */
	private function build_item_image_map( $items, $base_url = '', $expected_extension = '' ) {
		$map = array();

		foreach ( $items as $item ) {
			if ( empty( $item['name'] ) || empty( $item['file'] ) ) {
				continue;
			}

			$name         = sanitize_text_field( $item['name'] );
			$effective_base_url = '' !== (string) $base_url ? (string) $base_url : HSR_EDD_CHARACTERS_IMG_BASE_URL;
			$file_name = sanitize_file_name( (string) $item['file'] );
			if ( '' !== (string) $expected_extension ) {
				$file_name = pathinfo( $file_name, PATHINFO_FILENAME ) . '.' . sanitize_key( (string) $expected_extension );
			}
			$map[ $name ] = esc_url( $effective_base_url . ltrim( $file_name, '/' ) );
		}

		return $map;
	}

	/**
	 * @param string $post_status Post status.
	 * @return array{label:string,class:string}
	 */
	private function get_status_data( $post_status ) {
		if ( 'publish' === $post_status ) {
			return array(
				'label' => __( 'تایید شده', 'honkai-star-rail-edd-account-form' ),
				'class' => 'is-approved',
			);
		}

		if ( 'pending' === $post_status ) {
			return array(
				'label' => __( 'در حال بررسی', 'honkai-star-rail-edd-account-form' ),
				'class' => 'is-review',
			);
		}

		return array(
			'label' => __( 'رد شده', 'honkai-star-rail-edd-account-form' ),
			'class' => 'is-rejected',
		);
	}

	/**
	 * @param string $text Raw text.
	 * @return string
	 */
	private function prepare_hover_text( $text ) {
		$text = trim( $text );
		return '' !== $text ? $text : '-';
	}

	/**
	 * @param array<int,string>   $items Item names.
	 * @param array<string,string> $image_map Name to image map.
	 * @return array<int,array{name:string,image:string}>
	 */
	private function prepare_hover_items( $items, $image_map ) {
		$list = array();
		foreach ( $items as $name ) {
			$list[] = array(
				'name'  => $name,
				'image' => isset( $image_map[ $name ] ) ? $image_map[ $name ] : '',
			);
		}

		return $list;
	}
}
